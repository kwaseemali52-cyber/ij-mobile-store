IJ MOBILE STORE WEBSITE

Included:
- index.html: complete responsive website
- Product order buttons open WhatsApp with product name and listed price
- No paid libraries or images required

HOW TO USE:
1. Open index.html in a browser to preview.
2. To publish free: upload index.html to a GitHub repository, then connect the repository to Cloudflare Pages.
3. WhatsApp number currently set in the file: 923153528598. Replace it if needed.
4. Edit product names/prices in index.html to match your actual stock.
5. Confirm Cash on Delivery and delivery fees with your courier before advertising them.
